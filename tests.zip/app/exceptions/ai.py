class AIProviderUnavailableError(Exception):
    pass
